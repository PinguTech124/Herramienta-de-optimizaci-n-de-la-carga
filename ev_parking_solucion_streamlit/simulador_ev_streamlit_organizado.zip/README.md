
# Simulador de Carga de Vehículos Eléctricos — Versión Streamlit

Este proyecto permite simular, optimizar e inspeccionar la carga de vehículos eléctricos a través de una aplicación web en **Streamlit**.

## 📂 Estructura del proyecto

- `app/app_streamlit.py`: Aplicación principal con Streamlit.
- `src/modelos.py`: Clases y lógica de simulación y optimización.
- `data/simulacion.pkl`: Archivo con la simulación de vehículos y resultados.
- `output/`: Carpeta donde se guardan los gráficos exportados por día.
- `README.md`: Esta guía.
- `requirements.txt`: Dependencias necesarias para ejecutar el simulador.

## 🚀 Cómo ejecutar

1. Instala las dependencias (en un entorno limpio preferiblemente):

```bash
pip install -r requirements.txt
```

2. Ejecuta la aplicación con Streamlit:

```bash
streamlit run app/app_streamlit.py
```

## 📊 Funcionalidades

- Simulación de varios vehículos por día
- Optimización convexa para minimizar el uso total de potencia
- Visualización de curvas de energía y potencia
- Exportación de gráficos por día
- Resumen estadístico global

