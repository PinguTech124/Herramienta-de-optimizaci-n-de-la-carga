
from dataclasses import dataclass
from typing import List, Tuple, Dict
import numpy as np
import cvxpy as cp

@dataclass
class EVModel:
    nombre: str
    Emax: float
    Pmax: float

@dataclass
class Vehicle:
    modelo: EVModel
    slot_arr: int
    slot_dep: int
    E_arr: float
    E_dep: float

@dataclass
class DaySimulation:
    vehicles: List[Vehicle]

    def get_params_cars(self) -> List[Tuple[int, float, int, float]]:
        return [(v.slot_arr, v.E_arr, v.slot_dep, v.E_dep) for v in self.vehicles]

    def get_Pmax_cars(self) -> List[float]:
        return [v.modelo.Pmax for v in self.vehicles]

class FleetSimulator:
    def __init__(self, modelos_ev: Dict[str, Dict[str, float]], deltaT: float, 
                 t_arr_mean=7.0, t_arr_std=2.0, t_dep_mean=16.0, t_dep_std=2.0,
                 E_arr_range=(0.2, 0.8)):
        self.deltaT = deltaT
        self.t_arr_mean = t_arr_mean
        self.t_arr_std = t_arr_std
        self.t_dep_mean = t_dep_mean
        self.t_dep_std = t_dep_std
        self.E_arr_range = E_arr_range
        self.modelos = {
            nombre: EVModel(nombre, datos["Emax"], datos["Pmax"]) 
            for nombre, datos in modelos_ev.items()
        }

    def simular_dia(self, n_cars: int) -> DaySimulation:
        import random
        vehiculos = []
        for _ in range(n_cars):
            modelo_nombre = random.choice(list(self.modelos.keys()))
            modelo = self.modelos[modelo_nombre]
            t_arr = np.random.normal(self.t_arr_mean, self.t_arr_std)
            t_dep = np.random.normal(self.t_dep_mean, self.t_dep_std)
            slot_arr = max(0, int(np.floor(t_arr / self.deltaT)))
            slot_dep = int(np.floor(t_dep / self.deltaT))
            if slot_dep <= slot_arr:
                slot_dep = slot_arr + 1
            frac = random.uniform(*self.E_arr_range)
            E_arr = frac * modelo.Emax
            vehiculos.append(Vehicle(
                modelo=modelo,
                slot_arr=slot_arr,
                slot_dep=slot_dep,
                E_arr=E_arr,
                E_dep=modelo.Emax
            ))
        return DaySimulation(vehiculos)

@dataclass
class OptimResult:
    P_values: List[List[float]]
    total_power: List[float]
    value_objetivo: float

def optimizar_dia(dia: DaySimulation, deltaT: float, Pmax_parking_lot: float) -> OptimResult:
    params_cars = dia.get_params_cars()
    Pmax_cars = dia.get_Pmax_cars()
    n_cars = len(params_cars)
    max_slot = max(slot_dep for _, _, slot_dep, _ in params_cars)
    P = [cp.Variable(max_slot) for _ in range(n_cars)]

    total_power_per_slot = [
        sum(P[i][t] for i in range(n_cars) if params_cars[i][0] <= t < params_cars[i][2])
        for t in range(max_slot)
    ]
    objective = cp.Minimize(cp.sum_squares(cp.hstack(total_power_per_slot)))

    constraints = []
    for i in range(n_cars):
        slot_arr, E_arr, slot_dep, E_dep = params_cars[i]
        constraints.append(cp.sum(P[i][slot_arr:slot_dep]) * deltaT + E_arr == E_dep)
        for t in range(slot_arr, slot_dep):
            constraints.append(P[i][t] <= Pmax_cars[i])
            constraints.append(P[i][t] >= 0)

    for t in range(max_slot):
        total_power = sum(P[i][t] for i in range(n_cars) if params_cars[i][0] <= t < params_cars[i][2])
        constraints.append(total_power <= Pmax_parking_lot)

    problem = cp.Problem(objective, constraints)
    problem.solve()

    if problem.status != cp.OPTIMAL:
        return None

    P_values = [P[i].value.tolist() for i in range(n_cars)]
    total_power = [
        sum(P_values[i][t] for i in range(n_cars) if params_cars[i][0] <= t < params_cars[i][2])
        for t in range(max_slot)
    ]
    return OptimResult(P_values=P_values, total_power=total_power, value_objetivo=problem.value)
