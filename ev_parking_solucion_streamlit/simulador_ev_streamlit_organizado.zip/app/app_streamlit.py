
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import pickle
import os
from modelos import DaySimulation

st.sidebar.title("Menú")
opcion = st.sidebar.radio("Seleccione una opción", [
    "Preparar Datos",
    "Optimizar",
    "Inspeccionar Resultados",
    "Resumen Estadístico"
])

if opcion == "Resumen Estadístico":
    st.title("📊 Resumen Estadístico de la Simulación")

    try:
        with open("simulacion.pkl", "rb") as f:
            data = pickle.load(f)
        dias = data["dias"]
        deltaT = data["deltaT"]

        # Acumuladores
        modelos = {"A": {"coches": 0, "horas": 0.0, "energia": 0.0},
                   "B": {"coches": 0, "horas": 0.0, "energia": 0.0},
                   "C": {"coches": 0, "horas": 0.0, "energia": 0.0},
                   "D": {"coches": 0, "horas": 0.0, "energia": 0.0}}

        valores_obj = []

        for dia in dias:
            sim = DaySimulation(dia["vehiculos"])
            res = dia["resultado"]
            if res:
                valores_obj.append(res.value_objetivo)
                for i, veh in enumerate(sim.vehicles):
                    nombre = veh.modelo.nombre
                    modelos[nombre]["coches"] += 1
                    modelos[nombre]["horas"] += (veh.slot_dep - veh.slot_arr) * deltaT
                    energia = sum(res.P_values[i][veh.slot_arr:veh.slot_dep]) * deltaT
                    modelos[nombre]["energia"] += energia

        # Crear DataFrame
        df = pd.DataFrame([
            {
                "Modelo": m,
                "Nº Coches": modelos[m]["coches"],
                "Horas Conectadas": round(modelos[m]["horas"], 2),
                "Energía Consumida (kWh)": round(modelos[m]["energia"], 2)
            }
            for m in modelos
        ])
        st.subheader("Tabla de Modelos y Consumo")
        st.dataframe(df)

        # Gráfico histograma
        st.subheader("Distribución de la Función Objetivo")
        fig, ax = plt.subplots()
        ax.hist(valores_obj, bins=10)
        ax.set_xlabel("Valor función objetivo")
        ax.set_ylabel("Frecuencia")
        ax.set_title("Histograma de la función objetivo")
        st.pyplot(fig)

    except Exception as e:
        st.error(f"Error cargando datos: {e}")

elif opcion == "Preparar Datos":
    st.title("🚗 Preparación de Datos")
    st.info("Aquí iría la lógica para simular vehículos...")

elif opcion == "Optimizar":
    st.title("⚙️ Optimización")
    st.info("Aquí iría la ejecución del optimizador...")

elif opcion == "Inspeccionar Resultados":
    st.title("🔍 Inspección de Resultados")
    st.info("Aquí iría la visualización de resultados diarios...")
